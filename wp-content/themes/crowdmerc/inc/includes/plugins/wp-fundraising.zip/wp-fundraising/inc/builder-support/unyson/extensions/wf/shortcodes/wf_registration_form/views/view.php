<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

echo do_shortcode('[wp_fundraising_registration_form]');
