<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}
?>
<div class="woocommerce">
    <p class="woocommerce-info"><?php esc_html_e( 'No campaigns found here.', 'wp-fundraising' ); ?></p>
</div>