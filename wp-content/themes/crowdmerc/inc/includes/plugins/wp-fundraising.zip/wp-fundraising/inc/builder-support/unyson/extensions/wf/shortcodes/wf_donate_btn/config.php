<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$cfg = array(
	'page_builder' => array(
		'title'       => __( 'WF Donate Button', 'wp-fundraising' ),
		'tab'         => __( 'WP Fundraising', 'wp-fundraising' ),
		'popup_size'  => 'medium',
	)
);