<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$cfg = array(
	'page_builder' => array(
		'title'       => __( 'WF Donate Form', 'wp-fundraising' ),
		'tab'         => __( 'WP Fundraising', 'wp-fundraising' ),
		'popup_size'  => 'medium',
	)
);